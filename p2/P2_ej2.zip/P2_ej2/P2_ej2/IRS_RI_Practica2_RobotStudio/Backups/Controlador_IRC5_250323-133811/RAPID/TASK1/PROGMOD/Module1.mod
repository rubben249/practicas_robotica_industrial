MODULE Module1
        CONST robtarget aprox_rojo_arriba_mesa:=[[533.94,125.614,59.645],[0,0,1,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget rojo_arriba_mesa:=[[533.94,125.614,39.645],[0,0,1,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_cubo6_pedestal:=[[25.549279317,26.09461213,-342.046996466],[0.000457758,0.002162758,0.0021638,-0.999995215],[-1,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget cubo6_pedestal:=[[25.339411386,25.882309306,-292.826632575],[0.000457758,0.002162758,0.0021638,-0.999995215],[-1,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_rojo_abajo_mesa:=[[533.94,250.007672792,59.645],[0,0,1,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget rojo_abajo_mesa:=[[533.94,250.007672792,39.645],[0,0,1,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_cubo5_pedestal:=[[25.254654145,25.797431875,-273.222657828],[0.000457758,0.002162758,0.0021638,-0.999995215],[-1,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget cubo5_pedestal:=[[25.120317008,25.665050592,-242.832912358],[0.000457758,0.002162758,0.0021638,-0.999995215],[-1,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_verde_arriba_mesa:=[[438.734213561,123.598213564,60],[0,0.382683432,0.923879533,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget verde_arriba_mesa:=[[438.734213561,123.598213564,40],[0,0.382683432,0.923879533,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_cubo4_pedestal:=[[25.040384451,25.585004006,-224.344639308],[0.000457758,0.002162758,0.0021638,-0.999995215],[-1,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget cubo4_pedestal:=[[24.898685649,25.440965181,-190.890898963],[0.000457758,0.002162758,0.0021638,-0.999995215],[-1,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_verde_abajo_mesa:=[[435.029028035,252.504917123,59.645],[0,0.382683431,0.923879533,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget verde_abajo_mesa:=[[435.029028035,252.504917123,39.645],[0,0.382683431,0.923879533,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_cubo3_pedestal:=[[30.42096791,25.325653044,-163.237533234],[0.000457758,0.002162758,0.0021638,-0.999995215],[-1,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget cubo3_pedestal:=[[30.328703887,25.235855903,-142.312757971],[0.000457758,0.002162758,0.0021638,-0.999995215],[-1,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_blanco_arriba_mesa:=[[335.341333781,124.646829723,59.645],[0,0,1,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget blanco_arriba_mesa:=[[335.341333781,124.646829723,39.645],[0,0,1,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_cubo2_pedestal:=[[27.266373262,25.322794354,-163.251184928],[0.000457758,0.002162758,0.0021638,-0.999995215],[-1,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget cubo2_pedestal:=[[24.467094805,25.008772287,-91.069146441],[0.000457758,0.002162758,0.0021638,-0.999995215],[-1,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_blanco_abajo_mesa:=[[335.341333781,250.007672792,59.645],[0,0,1,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget blanco_abajo_mesa:=[[335.341333781,250.007672792,39.645],[0,0,1,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_cubo1_pedestal:=[[24.343935799,24.887581907,-63.263832832],[0.000457758,0.002162758,0.0021638,-0.999995215],[-1,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget cubo1_pedestal:=[[24.250158502,24.79153128,-40.893706829],[0.000457758,0.002162758,0.0021638,-0.999995215],[-1,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_cubo6_ped_coger:=[[25.36309876,-13.151520628,-290.806707862],[0.500227007,-0.49760545,-0.500225966,-0.501932008],[0,1,-1,1],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget cubo6_ped_coger:=[[25.339411386,25.882309306,-292.826632575],[0.500227007,-0.49760545,-0.500225966,-0.501932008],[0,1,-1,1],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_rojo_arriba_plataf:=[[243.457745108,34.48993352,-159.08793761],[0.499999999,-0.499999999,-0.500000001,-0.500000001],[0,-2,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget rojo_arriba_plataf:=[[243.906538693,133.195793854,-38.178674671],[0.499999999,-0.500000001,-0.499999999,-0.500000001],[0,-2,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget Home:=[[318,0,411.6],[0,0,1,0],[0,0,0,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_cubo5_ped_coger:=[[24.911428859,-6.83845608,-229.288823654],[0.500227007,-0.49760545,-0.500225966,-0.501932008],[0,1,-1,1],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget cubo5_ped_coger:=[[30.50939036,25.610734623,-229.124126392],[0.500227007,-0.49760545,-0.500225966,-0.501932008],[0,1,-1,1],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_rojo_abajo_plataf:=[[250.469249959,-0.607665298,-65.153333948],[0.499999999,-0.499999999,-0.500000001,-0.500000001],[0,-2,1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget rojo_abajo_plataf:=[[244.032373493,33.321628453,-24.989521495],[0.500000001,-0.500000001,-0.499999999,-0.499999999],[0,-2,1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_cubo4_ped_coger:=[[0.627579609,25.387847835,-183.986772295],[0.001853721,-0.705574097,0.001206354,-0.708632699],[-1,1,-2,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget cubo4_ped_coger:=[[30.293212649,25.394256051,-179.125062359],[0.001853721,-0.705574097,0.001206354,-0.708632699],[-1,1,-2,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget verde_arriba_plataf:=[[157.376586831,149.165841753,-28.258517858],[0.270598049,-0.653281483,-0.270598049,-0.653281483],[-1,-1,0,1],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_verde_abajo_plataf:=[[157.376587031,49.165841339,-68.480283741],[0.382683433,0,0,-0.923879532],[-1,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget verde_abajo_plataf:=[[157.376587031,49.165841753,-38.178674671],[0.382683431,0,0,-0.923879533],[-1,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_cubo2_ped_coger:=[[0.221042556,-7.171706916,-83.227310828],[0.500226988,-0.497605444,-0.500225985,-0.501932014],[0,1,-1,1],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget cubo2_ped_coger:=[[29.856964722,24.957400986,-78.226649224],[0.500226988,-0.497605444,-0.500225985,-0.501932014],[0,1,-1,1],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_blanco_arriba_plataf:=[[40.481081449,125.634648962,-41.100588955],[0.500000001,-0.499999999,-0.500000001,-0.499999999],[-1,-2,1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget blanco_arriba_plataf:=[[48.890339975,126.840686937,-28.68251683],[0.499999999,-0.500000001,-0.499999999,-0.500000001],[-1,-2,1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget aprox_blanco_abajo_plataf:=[[53.876587031,49.165841546,-68.480283741],[-0.000000001,0,0,1],[-1,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
    CONST robtarget blanco_abajo_plataf:=[[53.876587031,49.165841546,-42.881436214],[0.000000001,0,0,1],[-1,0,-1,0],[9E+09,9E+09,9E+09,9E+09,9E+09,9E+09]];
!***********************************************************
    !
    ! M�dulo:  Module1
    !
    ! Descripci�n:
    !   <Introduzca la descripci�n aqu�>
    !
    ! Autor: Rub�n
    !
    ! Versi�n: 1.0
    !
    !***********************************************************
    
    
    !***********************************************************
    !
    ! Procedimiento Main
    !
    !   Este es el punto de entrada de su programa
    !
    !***********************************************************
    VAR num num_cubos := 3;
    PROC moverCubos()
        IF num_cubos >= 1 THEN
            cubo1;
        ENDIF
        IF num_cubos >= 2 THEN
            cubo2;
        ENDIF
        IF num_cubos >= 3 THEN
            cubo3;
        ENDIF
        IF num_cubos >= 4 THEN
            cubo4;
        ENDIF
        IF num_cubos >= 5 THEN
            cubo5;
        ENDIF
        IF num_cubos >= 6 THEN
            cubo6;
        ENDIF
    ENDPROC
    
    PROC dejarCubos()
        IF num_cubos >= 6 THEN
            cubo6_dejar;
        ENDIF
        IF num_cubos >= 5 THEN
            cubo5_dejar;
        ENDIF
        IF num_cubos >= 4 THEN
            cubo4_dejar;
        ENDIF
        IF num_cubos >= 3 THEN
            cubo3_dejar;
        ENDIF
        IF num_cubos >= 2 THEN
            cubo2_dejar;
        ENDIF
        IF num_cubos >= 1 THEN
            cubo1_dejar;
        ENDIF
    ENDPROC
    
    PROC main()
        ! Posici�n segura
        MoveJ Home, v400, fine, Pinza_schunk_SGB50_1\WObj:=wobj0;
    
        ! Recoger desde mesa y colocar en pedestal
        moverCubos;
    
        WaitTime 2;
    
        ! Recoger desde pedestal y colocar en plataforma
        dejarCubos;
    
        ! Regresar a Home
        MoveJ Home, v400, fine, Pinza_schunk_SGB50_1\WObj:=wobj0;
    ENDPROC
    
    PROC cubo6()
        MoveJ aprox_rojo_arriba_mesa,v400,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        MoveL rojo_arriba_mesa,v200,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        SetDO D16_O,1;
        WaitTime 1;
        MoveL aprox_rojo_arriba_mesa,v400,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        MoveJ aprox_cubo6_pedestal,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveL cubo6_pedestal,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        SetDO D16_O,0;
        WaitTime 1;
        MoveL aprox_cubo6_pedestal,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveL Home,v400,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
    ENDPROC
    PROC cubo5()
        MoveJ aprox_rojo_abajo_mesa,v400,z0,Pinza_schunk_SGB50_1\WObj:=wobj0;
        MoveL rojo_abajo_mesa,v200,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        SetDO D16_O,1;
        WaitTime 1;
        MoveL aprox_rojo_abajo_mesa,v400,z0,Pinza_schunk_SGB50_1\WObj:=wobj0;
        MoveL aprox_cubo5_pedestal,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveL cubo5_pedestal,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        SetDO D16_O,0;
        WaitTime 1;
        MoveL aprox_cubo5_pedestal,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
    ENDPROC
    PROC cubo4()
        MoveJ aprox_verde_arriba_mesa,v400,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        WaitTime 1;
        MoveL verde_arriba_mesa,v1000,z100,Pinza_schunk_SGB50_1\WObj:=wobj0;
        WaitTime 1;
        SetDO D16_O,1;
        WaitTime 1;
        MoveL aprox_verde_arriba_mesa,v400,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        MoveJ aprox_cubo4_pedestal,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveL cubo4_pedestal,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        SetDO D16_O,0;
        WaitTime 1;
        MoveL aprox_cubo4_pedestal,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
    ENDPROC
    PROC cubo3()
        MoveJ aprox_verde_abajo_mesa,v400,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        MoveL verde_abajo_mesa,v200,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        SetDO D16_O,1;
        WaitTime 1;
        MoveL aprox_verde_abajo_mesa,v200,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        MoveJ aprox_cubo3_pedestal,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveL cubo3_pedestal,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        SetDO D16_O,0;
        WaitTime 1;
        MoveL aprox_cubo3_pedestal,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
    ENDPROC
    PROC cubo2()
        MoveJ aprox_blanco_arriba_mesa,v400,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        MoveL blanco_arriba_mesa,v200,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        SetDO D16_O,1;
        WaitTime 1;
        MoveL aprox_blanco_arriba_mesa,v200,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        MoveJ aprox_cubo2_pedestal,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveL cubo2_pedestal,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        SetDO D16_O,0;
        WaitTime 1;
        MoveL aprox_cubo2_pedestal,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
    ENDPROC
    PROC cubo1()
        SetDO D16_O,0;
        WaitTime 1;
        MoveJ aprox_blanco_abajo_mesa,v400,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        MoveL blanco_abajo_mesa,v200,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        SetDO D16_O,1;
        WaitTime 1;
        MoveL aprox_blanco_abajo_mesa,v200,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        MoveJ aprox_cubo1_pedestal,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveL cubo1_pedestal,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        SetDO D16_O,0;
        WaitTime 1;
        MoveL aprox_cubo1_pedestal,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
    ENDPROC
    PROC cubo6_dejar()
        MoveJ aprox_cubo6_ped_coger,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveL cubo6_ped_coger,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        SetDO D16_O,1;
        WaitTime 1;
        MoveL aprox_cubo6_ped_coger,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveJ Home,v400,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        MoveJ aprox_rojo_arriba_plataf,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Plataforma;
        MoveL rojo_arriba_plataf,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Plataforma;
        SetDO D16_O,0;
        WaitTime 1;
        MoveL aprox_rojo_arriba_plataf,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Plataforma;
        MoveL Home,v400,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
    ENDPROC
    PROC cubo5_dejar()
        MoveJ aprox_cubo5_ped_coger,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveL cubo5_ped_coger,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        SetDO D16_O,1;
        WaitTime 1;
        MoveL aprox_cubo5_ped_coger,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveJ Home,v400,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        MoveJ aprox_rojo_abajo_plataf,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Plataforma;
        MoveL rojo_abajo_plataf,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Plataforma;
        SetDO D16_O,0;
        WaitTime 1;
        MoveL aprox_rojo_abajo_plataf,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Plataforma;
        MoveL Home,v400,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
    ENDPROC
    PROC cubo4_dejar()
        MoveL aprox_cubo4_ped_coger,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveL cubo4_ped_coger,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        SetDO D16_O,1;
        WaitTime 1;
        MoveL aprox_cubo4_ped_coger,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveJ Home,v200,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        MoveJ verde_arriba_plataf,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Plataforma;
        SetDO D16_O,0;
        WaitTime 1;
        MoveJ Home,v400,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
    ENDPROC
    PROC cubo3_dejar()
        MoveL aprox_cubo3_pedestal,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveL cubo3_pedestal,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        SetDO D16_O,1;
        WaitTime 1;
        MoveL aprox_cubo3_pedestal,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveJ Home,v200,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        MoveJ aprox_verde_abajo_plataf,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Plataforma;
        MoveL verde_abajo_plataf,v1000,fine,Pinza_schunk_SGB50_1\WObj:=WO_Plataforma;
        SetDO D16_O,0;
        WaitTime 1;
        MoveL aprox_verde_abajo_plataf,v1000,fine,Pinza_schunk_SGB50_1\WObj:=WO_Plataforma;
        MoveJ Home,v400,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
    ENDPROC
    PROC cubo2_dejar()
        MoveJ aprox_cubo2_ped_coger,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveL cubo2_ped_coger,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        SetDO D16_O,1;
        WaitTime 1;
        MoveL aprox_cubo2_ped_coger,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveJ Home,v400,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
        MoveJ aprox_blanco_arriba_plataf,v400,fine,Pinza_schunk_SGB50_1\WObj:=WO_Plataforma;
        MoveL blanco_arriba_plataf,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Plataforma;
        SetDO D16_O,0;
        WaitTime 1;
        MoveL aprox_blanco_arriba_plataf,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Plataforma;
        MoveJ Home,v400,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
    ENDPROC
    PROC cubo1_dejar()
        MoveL aprox_cubo1_pedestal,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveL cubo1_pedestal,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        SetDO D16_O,1;
        WaitTime 1;
        MoveL aprox_cubo1_pedestal,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Soporte;
        MoveL aprox_blanco_abajo_plataf,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Plataforma;
        MoveL blanco_abajo_plataf,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Plataforma;
        SetDO D16_O,0;
        WaitTime 1;
        MoveL aprox_blanco_abajo_plataf,v200,fine,Pinza_schunk_SGB50_1\WObj:=WO_Plataforma;
        MoveJ Home,v400,fine,Pinza_schunk_SGB50_1\WObj:=wobj0;
    ENDPROC
ENDMODULE