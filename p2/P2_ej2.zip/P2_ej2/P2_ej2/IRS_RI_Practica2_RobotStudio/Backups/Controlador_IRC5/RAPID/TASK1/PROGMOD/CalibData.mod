MODULE CalibData
	PERS tooldata Pinza_schunk_SGB50_1:=[TRUE,[[-16,0,146.4],[1,0,0,0]],[0.1393,[-13.76,0,75.83],[1,0,0,0],0,0,0]];
ENDMODULE