MODULE Module1
	PERS tooldata Soldador:=[TRUE,[[0,0,0],[1,0,0,0]],[2,[0,0,0],[1,0,0,0],0,0,0]];
    !***********************************************************
    !
    ! M?dulo:  Module1
    !
    ! Descripci�n:
    !   <Introduzca la descripci�n aqu�>
    !
    ! Autor: victo
    !
    ! Versi�n: 1.0
    !
    !***********************************************************
    
    
    !***********************************************************
    !
    ! Procedimiento Main
    !
    !   Este es el punto de entrada de su programa
    !
    !***********************************************************
    PROC main()
        !Add your code here
    ENDPROC
ENDMODULE