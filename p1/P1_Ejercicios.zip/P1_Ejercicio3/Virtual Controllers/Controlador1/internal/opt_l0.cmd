
include -path "C:/Users/victo/AppData/Local/ABB/RobotWare/RobotControl_7.12.0/options/sc/ScInc_opt.cmd"
